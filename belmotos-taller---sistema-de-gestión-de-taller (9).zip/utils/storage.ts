
// BELMOTOS - Storage Engine
const STORAGE_KEY = 'belmotos_data';

export const getOrders = () => {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
};

export const saveOrders = (orders) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(orders));
};

export const generateOrderId = () => {
    return Math.floor(100000 + Math.random() * 900000).toString();
};

export const seedDemoData = () => {
    // Función vacía para evitar la creación de datos de demostración
    // saveOrders([]); 
};
