
import { jsPDF } from 'jspdf';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

export const generateOrderPDF = (order: any) => {
  const doc = new jsPDF();
  const margin = 15;
  let y = 15;

  // Header Design
  doc.setFillColor(5, 150, 105);
  doc.rect(0, 0, 210, 40, 'F');
  
  doc.setFontSize(24);
  doc.setTextColor(255);
  doc.setFont('helvetica', 'bold');
  doc.text('BELMOTOS-TALLER', margin, 25);
  
  doc.setFontSize(10);
  doc.setTextColor(230);
  doc.setFont('helvetica', 'normal');
  doc.text('FICHA DE RECEPCIÓN Y DIAGNÓSTICO', margin, 32);
  
  doc.setFontSize(16);
  doc.text(`ORDEN #${order.id}`, 160, 25);
  y = 50;

  // Info Section
  doc.setTextColor(0);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.text('DATOS DEL PROPIETARIO', margin, y);
  doc.text('DATOS DEL VEHÍCULO', 105, y);
  y += 5;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  
  const ownerLines = [
    `Nombre: ${order.owner.name}`,
    `CI / RIF: ${order.owner.idNumber}`,
    `Teléfono: ${order.owner.phone}`,
    `Email: ${order.owner.email || 'N/A'}`
  ];
  ownerLines.forEach((l, i) => doc.text(l, margin, y + (i * 5)));

  const motoLines = [
    `Placa: ${order.motorcycle.plate}`,
    `Modelo: ${order.motorcycle.model}`,
    `KM: ${order.motorcycle.mileage} | Año: ${order.motorcycle.year}`,
    `Chasis: ${order.motorcycle.chassisSerial}`,
    `Motor: ${order.motorcycle.engineSerial}`
  ];
  motoLines.forEach((l, i) => doc.text(l, 105, y + (i * 5)));
  y += 35;

  // Inventory Section
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.text('INVENTARIO FÍSICO (CHECKLIST)', margin, y);
  y += 6;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7);
  const checklist = Object.entries(order.checklist);
  checklist.forEach(([item, checked], i) => {
    const col = i % 3;
    const row = Math.floor(i / 3);
    const mark = checked ? '[X]' : '[ ]';
    doc.text(`${mark} ${item}`, margin + (col * 60), y + (row * 4.5));
  });
  y += (Math.ceil(checklist.length / 3) * 4.5) + 10;

  // Observations & Report
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text('REPORTE DEL CLIENTE:', margin, y);
  y += 5;
  doc.setFont('helvetica', 'normal');
  const reportLines = doc.splitTextToSize(order.clientReport || 'Sin reporte detallado.', 180);
  doc.text(reportLines, margin, y);
  y += (reportLines.length * 5) + 5;

  doc.setFont('helvetica', 'bold');
  doc.text('OBSERVACIONES GENERALES (TALLER):', margin, y);
  y += 5;
  doc.setFont('helvetica', 'normal');
  const obsLines = doc.splitTextToSize(order.observations || 'Sin observaciones adicionales.', 180);
  doc.text(obsLines, margin, y);
  y += (obsLines.length * 5) + 10;

  // Photos
  if (order.photoVehicle || order.photoChassis) {
    if (y > 200) { doc.addPage(); y = 20; }
    doc.setFont('helvetica', 'bold');
    doc.text('EVIDENCIA FOTOGRÁFICA:', margin, y);
    y += 5;
    if (order.photoVehicle) {
      try { doc.addImage(order.photoVehicle, 'JPEG', margin, y, 85, 50); } catch (e) {}
    }
    if (order.photoChassis) {
      try { doc.addImage(order.photoChassis, 'JPEG', margin + 95, y, 85, 50); } catch (e) {}
    }
    y += 55;
  }

  // Legal
  if (y > 240) { doc.addPage(); y = 20; }
  doc.setFontSize(6);
  doc.setFont('helvetica', 'italic');
  const legal = "Condiciones: La empresa no responde por objetos dejados en la unidad. Trabajos cancelados al retiro. Plazo de 24h para presupuestos. Al firmar acepta condiciones generales de BELMOTOS.";
  doc.text(doc.splitTextToSize(legal, 180), margin, y);

  // Foot
  y = 275;
  doc.line(margin, y, 80, y);
  doc.line(120, y, 195, y);
  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.text('FIRMA RECIBIDO (TALLER)', margin + 15, y + 5);
  doc.text('FIRMA CONFORMIDAD (CLIENTE)', 135, y + 5);

  doc.save(`Recepcion_${order.motorcycle.plate}_${order.id}.pdf`);
};

export const generateTechnicalReportPDF = (order: any) => {
  const doc = new jsPDF();
  const margin = 20;
  let y = 25;

  doc.setFontSize(24);
  doc.setTextColor(5, 150, 105);
  doc.setFont('helvetica', 'bold');
  doc.text('INFORME TÉCNICO', margin, y);
  y += 15;

  doc.setFontSize(10);
  doc.setTextColor(100);
  doc.text(`Vehículo: ${order.motorcycle.model} | Placa: ${order.motorcycle.plate}`, margin, y);
  doc.text(`Fecha Entrega: ${format(new Date(), 'PPP', { locale: es })}`, 130, y);
  y += 10;
  doc.line(margin, y, 190, y);
  y += 15;

  doc.setFontSize(12);
  doc.setTextColor(0);
  doc.setFont('helvetica', 'bold');
  doc.text('TRABAJO REALIZADO:', margin, y);
  y += 8;
  doc.setFont('helvetica', 'normal');
  const notes = doc.splitTextToSize(order.technicianNotes || 'Reparaciones estándar efectuadas.', 170);
  doc.text(notes, margin, y);
  y += (notes.length * 6) + 15;

  doc.setFont('helvetica', 'bold');
  doc.text('RESUMEN DE CARGOS:', margin, y);
  y += 8;
  doc.setFont('helvetica', 'normal');
  doc.text(`Mano de obra (Horas): ${order.workHours}`, margin, y);
  doc.text(`TOTAL A PAGAR: $ ${order.estimatedCost.toLocaleString()}`, margin, y + 7);
  
  y += 40;
  doc.text('Gracias por elegir BELMOTOS.', margin, y);

  doc.save(`InformeTecnico_${order.motorcycle.plate}_${order.id}.pdf`);
};
